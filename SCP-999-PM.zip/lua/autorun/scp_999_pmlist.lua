player_manager.AddValidModel( "scp_999_rba", "models/scp/999/jq/scp_999_pmjq.mdl" )
list.Set( "PlayerOptionsModel", "scp_999_rba", "models/scp/999/jq/scp_999_pmjq.mdl" )